// en c no existen los objetos y clases. vamos a usar "struct"s

// megarepaso

#include <stdio.h>
#include <stdbool.h>

int main1(){
    printf("hello world");
    return 0;     // porque le dije que devuelve un int al ppio. 
}

// se compila con :
//      gcc  -g    tutorial.c -o  nombre_del_binario 
//           -evitable           (gralmente es igual q el nombre del archivo)   hay muchos agregados. 

// buscar una tabla de cuanto vale cada type en bytes. 

// podes guardar en un Char algo q pesa hasta 128. si pesa un solo bit más te hace un -cosa- mod 128

int suma (int a, int b){        // lo preparé para que entre un int (mediano)
    int suma = a + b;
    return suma; 
}

int main2() {
    char a = 14;                // le pasé algo mucho más chico, entra, funciona piola √
    int b = 3;
    long c = 2;                 // si le paso algo más grande a lo que espera explota. X
    //casteo: si lo casteas a algo más chico te lo trunca!!!
    char d = (char) c;           // en este caso solo le saca los 0s de más que tiene ese c = 2
    d++ ;                        // es como hacer c = c+1 , o c += 1 (ambas valen)
    printf("%c",d);
    return suma(a,b);
}

// al char lo llena de ceros y lo castea a algo más grande.
// al long le sobran ceros, y "c" tiene miedo de que alguno de los ceros que no leyó tenga info, entonces explota antes de hacer cualquier cosa: Stack Overflow.

/* hacer una funcion que da True si un número es par */

bool isPar(char a){
    if(a % 2 == 0){
        return true;
    }else{
        return false;
    }
};
// otra ofrma es directamente       return (n%2)==0         sin hacer ifs...

/* hacer una funcion que da True si un año es bisiesto */

bool isBis(int year){
    if(((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0) ){
        return true;
    }else{
        return false;
    }
}

int main(){
    char a = isPar(1);
    char b = isPar(2);
    char c = isBis(2);
    char d = isBis(4);
    printf("%c,%c,%c,%c",a,b,c,d);
    return 0;
}




11 abril 5:50pm \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ 

ARBOL BINARIO DE BÚSQUEDA

de cada nodo sale sí o sí uno menor a la izq y uno mayor a la derecha.
    cada subarbol es un arbol binario de búsqueda.
    cada sub a la derecha tiene todos los nodos menores a la raíz y viceversa.

implementación:

struct ABB{
    node * root;
    size_t cont;
}

struct node{
    node * left;
    node * right;
    int value;
}

peor caso: el arbol no está balanceado, es una lista (filita de nodos sin ramas)
    O(n) para buscar, insertar y borrar.
    O(n) para recorrerlo.

mejor caso: el arbol está balanceado, es un árbol completo.
    O(log n) para buscar, insertar y borrar.
    O(n) para recorrerlo.

caso promedio: el arbol está balanceado, pero no es completo.
    O(log n) para buscar, insertar y borrar.
    O(n) para recorrerlo.

mejor caso de todos: el arbol tiene un solo nodo. (o estoy buscando el nodo que está en la raíz)
    O(1) para buscar, insertar y borrar.
    O(1) para recorrerlo.

\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
implementación para hallar la altura de un arbol cualquiera: 

int altura(node * root){
    if(!root) return 0;
    if(!root->left && !root->right) return 0; // en pseudocódigo: if(esHoja) return 0;
    return 1 + max(
        altura(root->left),
        altura(root->right));
}

implementación para hallar el máx value de un arbol cualquiera: 

int maxNode(node * root){
    if(!root) return 0;
    if(!root->left && !root->right) return root->value; 
    return max(
        root->value,
        max(
            maxNode(root->left),
            maxNode(root->right)));
 // maxLeft  = maxNode(root->left);
 // maxRight = maxNode(root->right);
    // return max(maxLeft,maxRight,root->value); es pseudo, no se puede hacer así: max recibe 2 cosas, no 3.
}
    
función para saber si el arbol es un arbol binario de búsqueda:

bool isABB (node * root){
    if(!root) return true;
    if(!root->left && !root->right) return true;
 // if(root->left && root->left->value > root->value) return false;         // copilot
 // if(root->right && root->right->value < root->value) return false;
    return isABB(root->left) && isABB(root->right);
            && root->value > maxNode(root->left)
            && root->value <= maxNode(root->right);
}

un árbol balanceado es uno tal que 
la diferencia de alturas entre 
    el subarbol izq y 
    el derecho 
        es a lo sumo 1.

un árbol completo es uno tal que 
    todos los niveles están completos, la dif de alturas es 0
    cantidad de nodos = 2^(h+1) - 1     //con h = altura

bool esBalanceado (node * root){
    if(!root) return true;
    if(!root->left && !root->right) return true;
    return abs(altura(root->left) - altura(root->right)) <= 1
        && esBalanceado(root->left)
        && esBalanceado(root->right);
} // es O(n^2) porque calcula la altura de cada nodo, y la altura de cada nodo calcula la altura de cada nodo de sus hijos.
// se puede amortizar a O(n) si se hacen las dos recursiones a la vez: la de la altura y la de si esta balanceado. 

ejercicio: armar un ABB completo con una lista (1,2,3,4,5,6,7, ... ,2^k-1).

node * armarABB(int n){
    if(n == 0) return NULL;
    node * root = new node;
    root->value = n;
    root->left = armarABB(n-1);
    root->right = armarABB(n-1);
    return root;
} // COPILOT DICE QUE ESTÁ MAL, PERO NO DICE POR QUÉ. 