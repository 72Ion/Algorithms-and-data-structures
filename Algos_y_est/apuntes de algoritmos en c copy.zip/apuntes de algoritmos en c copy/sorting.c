nota: el mejor caso de todo sorting es cuando hay un solo elemento
este caso es *irrelevante* 
el mejor caso según piden los libros es el caso amortizado, es decir, el caso promedio. 

⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄
// tipos de sorting:

// - Bubble    Sort    O(n^2)
    si no te lo sabes me preocupo. 
    es in-place
    es estable
    el mejor caso es cuando ya está ordenado
    el peor  caso es cuando está ordenado al revés
    mejora: si no hubo cambios en una iteración, ya está ordenado.
    no lo usa nadie. es muy lento.

// - Selection Sort    O(n^2)
    busca el mínimo y lo pone al principio (o máximo y lo pone al final)
    - o busca el max y lo pone al principio (o min y lo pone al final) para ordenar al revés. 

// - Insertion Sort    O(n^2)
    toma un elemento al ppio o al final de la lista, itera sobre el resto y lo mete donde va. 
    es mejor para ordenar listas pequeñas xq baja mucho el O() 

    el mejor caso es cuando ya esta ordenado o casi         O(n)
    caso incómodo: si hay un elemento muy chico al final
    el peor  caso es cuando esta ordenado al reves

    mejora: binary-search InsertionSort
        busca el lugar donde insertar el elemento con binary-search (en vez de lineal) y luego lo inserta
        O(n log n) en vez de O(n^2)

// - Merge     Sort    O(n log n) (Divide and Conquer)
    es un árbol binario (de recursión) 
    orden de memoria: O(n) (porque duplica todo) 
    no tiene mejor y peor caso (siempre es O(n log n))
    no se puede hacer in-place (si o si duplica la memoria)
    - riesgo de stack overflow: 
        para evitarlo a veces se lo combina con otro algoritmo después de algunas divisiones del array

// - Heap      Sort    O(n log n) 
    se puede hacer in-place (sin duplicar la memoria)

// - Quick     Sort    O(n log n) (amortizado)
    elije una posición (pivot) y ordena los elementos a la izquierda y derecha de él
    el mejor caso es cuando el pivot es el elemento del medio
    el peor  caso es cuando el pivot es el primer o último elemento - O(n^2)}
        además el peor caso es cuando el array está ordenado al revés (o casi)
    es in-place
    no es estable
    amortizado: podemos elejir al azar un número impar de pivots y elejimos el del medio 
        eso nos ayuda a que el pivot elejido al azar esté cuanto más cerca del medio y ahorre pasos. 

/* diferencia entre Merge y Quick: 
    - Merge es más rápido incluso en el peor caso, pero ocupa más memoria
    - Quick es más lento en el peor caso (al menos O(n)) pero no ocupa memoria extra    */


    __________________________ALGORITMOS DE ORDENAMIENTO SIN COMPARAR VALORES___________________________

// Bucket Sort
    - O(n) en el mejor caso
    - O(n^2) en el peor caso
    usa listas para ordenar de un dígito 
    no es in-place
    nunca compara los valores que entraron a la lista como son
    sirve para ordenar unsigned int s via comparar sus bytes

// Counting Sort (count)
    - O(n) 
    - no tiene mejor ni peor caso
    cuenta la cantidad de 0s, 1s, 2s, etc y los pone en orden en un array auxiliar en O(2n) lineal 
    no es in-place
    no compara los valores que entraron a la lista como son
    itera una vez sobre el vector y se guarda esta info en un vector auxiliar: 
        hay algún 0? cuántos? 1? listo lo guardo al 1 en el lugar vect-aux[0] 
        hay algún 1? cuántos? 2? listo lo guardo al 2 en el lugar vect-aux[1] 
        etc...
        al final de todo queda un vector con las cantidades de -el número i- que hay en vec.
        crea un vec repitiendo i la cantidad vect-aux[i] de veces. 

    _________________________________ALGORITMOS DE ORDENAMIENTO HÍBRIDOS__________________________________

// Introspective Sort
    - O(n log n) en el peor caso
    - O(n) en el mejor caso
    - O(n log n) en el caso promedio

    es una mezcla de Quick, Heap y Merge:
        Quick Sort      hasta elementos ~ log(n)
        Merge Sort      hasta elementos ~ n (profe escribio k en vez de n)
        Heap Sort       el resto 

    es in-place
    No es estable
    es el más rápido en la mayoría de los casos
    es el más usado en la práctica

// Tim Sort
    es una mezcla de Merge y Insertion
    busca secuencias de al menos k elementos ya ordenados (y las ordena con Merge Sort)

    No es in-place
    es estable
    es el más rápido en la mayoría de los casos
    es el más usado en la práctica en Pyhton y Java 

⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄
Estabilidad: si dos elementos son iguales, el orden de ellos no cambia
    - Bubble    Sort    estable
    - Selection Sort    estable
    - Insertion Sort    estable puede ser inestable (depende donde decidis meter un elemento en igualdad)
    - Merge     Sort    estable puede ser inestable
    - Heap      Sort    inestable
    - Quick     Sort    inestable

estable: significa que si dos elementos son iguales, el orden original de ellos no cambia
inestable: significa que si dos elementos son iguales, el orden original de ellos puede cambiar o cambia. 
    orden original: como vienen dados 
    cambio: como quedan después de ordenarse. 

// Checkear la página BigOCheatSheet para ver los tiempos de ejecución de los algoritmos de sorting


⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄
// TEOREMA: 
             no se puede ordenar por comparación en menos de O(n log n) 

{a,b,c}                  __ posibilidades __
                   _____/                   \_____
                a < b                           a ≥ b 
              /       \ 
             /         \                 etc... 
            /           \
           /             \ 
        a < c           a ≥ c                      etc... 
        /   \           /   \
       /     \         /     \ 
    b < c   b ≥ c   b < c   b ≥ c
     / \     / \     / \     / \
  abc      acb                 cab  

    alto:  log(n!)
    ancho:  n!

⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄⁄




Heaps: 

un min heap es un arbol en el que, para todo nodo, el padre es mayor a ambos hijos. 
por la propiedad del heap, el mínimo elemento del min-heap es el nodo raíz, osea el 1ro y obtenerlo es O(1). 
para extraer el min hay que usar un algoritmo que lo reordene, que se llama sift-down (y es O(log n) según copilot).

el heapyfy usa sift-down para ordenar un array creando un heap. 

    para representarlo en la computadora, es más conveniente usar un arbol completo izquierda, ya que el completo derecha podría dejar espacios de memoria en blanco al pepe. 

como el arbol es completo, no hay forma de que quede una lista enlazada de nivel 1 contínua. sí o sí, del 1er nodo salen otros dos, o el único que tiene es una hoja, o es él el único nodo. 

// para veriifcar si es un min-heap 
bool verificar(int * arr , int n){
    for (int i = 0; i < n; i++){
        left = 2*i + 1;
        right = 2*i + 2;
  //    if     (arr[i] > arr[left] || arr[i] > arr[right]) return false; 
 // AKA if not((arr[i] < arr[left] && arr[i] < arr[right])) return false;

    if (left  < n && arr[i] > arr[left])  return false;
    if (right < n && arr[i] > arr[right]) return false; 

    // la n se fija si el nodo está en rango, es decir tiene hijos o no. (recordar que los de la derecha pueden estar vacíos).

    }    return true;
}


los Heaps NO son listas enlazadas (sería ineficiente)
las listas enlazadas son mejores para otras cosas
las LE no son indexables: habría que iterar hasta llegar al nodo que quiero y pierde efectividad. 
los Heaps son simples arrays indexables. 