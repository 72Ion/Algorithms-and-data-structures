B tree:

Es un árbol balanceado, donde cada nodo tiene n claves y n+1 hijos.

                   [ 1 ]
             ____/       \____
            /                 \
      [ 1    2 ]             [  1  ]
   /      |      \          /        \
[1 2]   [1 2]   [1 2 3]   [1 2]    [1 2 3]

B+ tree:

Tiene la misma estructura que el B tree, pero en vez de tener los datos en los nodos, los datos están en las hojas.

Pero: 
    1) las hojas tienen las claves y valores
    los nodos internos tienen valores de separación

    2) las hojas están enlazadas con lista doblemente enlazada (doble encadenada)

                   [ 1 ]
             ____/        \____
            /                  \
      [ 1    2 ]      ->      [  1  ]
      [        ]      <-      [     ]
   /      |      \           /        \
[1 2] > [1 2] > [1 2 3] -> [1 2] -> [1 2 3]
[   ] < [   ] < [     ] <- [   ] <- [     ]