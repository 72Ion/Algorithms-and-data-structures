/*

los punteros son ints, tienen una dirección de memoria a un número en tu computadora
todos los punteros pesan lo mismo: int

los strings y arrays siempre pesan uno más de lo q tienen xq terminan en /0

*/

struct C {
    int a;
    char b;
    int c;
    char d;
};

struct S s = {1,2,3,4}; 

/* en memoria parece algo así:

s.a     0001
s.b     2---
s.c     0003
s.d     4---

# los "-" son basura, memoria gastada en nada. */

SEGMENTOS DE MEMORIA 

code segment
    de solo lectura ejecutable a donde va el código y las constantes.
data segment
    variables creadas al inicio del programa y son válidas hasta que termina; pueden ser de acceso global o local.
stack
    variables creadas al inicio de una llamana a una función y destruidas automáticamente cuando esta llamada termina.
// stack overflow (ejemplo, fibonacci recursivo)
heap
    variables cuya duración está controlada por el programador
// malloc, calloc, free, new, delete, realloc

duración (lifetime):
scope


recordamos:
declarar es decir que existen
definir es ambos declarar y reservar los recursos necesarios, es decir ya meterle la información. 


int g = 1;                      //es global.                                data segment
static int I = 1;              // es local (este file)                      data segment
extern char e;                //llama a una var q existe en otro file       name

void Fa(){}                 //global                                        code segment
static void Fb(){}          //local (este file)                             code segment
void Fc();                  //no asigna memoria                             declaración

void Fc(int arg){           // COMPLETAR CON FOTO 27_FEB_3:00
    int a=1;
    static int b = 1;
    void * p = malloc(4);
    free(p);
    char * c = "ABC";
    char ar[] = "ABC"
}

un buffer es un conjunto de bytes seguidos, es memoria. 

malloc es un llamado a una función para que el SO me asigne un espacio de memoria. si el llamado fracasa devuelve null. 





