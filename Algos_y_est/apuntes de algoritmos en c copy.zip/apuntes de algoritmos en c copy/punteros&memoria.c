// un puntero es una dirección de memoria. 

// <tipo de var>* nombrePuntero = & variable ; 

// para desrefereciar:

nombrePuntero;

variable = *nombrePuntero ; 


char main(){

    int  a = 10;
    int* p = &a;
    int  b = *p; // b es 10. 

    printf("el valor de a es: %u\n", a);
    printf("la direccion de memoria de a es: %p\n", p);
    printf("el valor de b es: %u\n", b);

    char null; // esto no se hace !!!!!111!11!! >>> averiguar cómo se escribe null Null NULL nULL ... 
    int* a = null;
    // si yo le pido que me imprima " *a " al SO me tira segmentation fault y TP desaprobado.
    // SIEMPRE TENGO QUE CHECKEAR SI UN PUNTERO ES NULL //

    if (a) {
        return "a no era null";
    }
    if (!a){
        return "menos mal que checkeaste, sino esto iba a segmentation fault X|";
    }

    // void *malloc(size_t size); // size_t es algo positivo, por ej un unsigned int 
    // malloc devuelve un puntero a void. a menos que lo castees... (int*) 
    int * num = (int *) malloc(sizeof(int)); 
    // malloc puede llegar a devolver el puntero a null, si por ej le pido más memoria de la que dispongo. 
    int * num = (int *) malloc(sizeof(int) *3 ); // memoria para 3 ints (por 3)

    //CADA VEZ QUE HACES UN MALLOC TENES QUE HACER UN FREE!!! >>> leaks. 

    void free();
    // si haces free de un null no pasa nada :) 

    void *realloc(void* ptr, size_t size);
    // sirve para esas listas dinamicas que le pasas 2 bytes, necesitas un 3ro y le pedis q te la duplique a 4 con un realloc. 

    void *calloc(size_t size); // cero alloc: te mete un montón de ceros en tu size pedido. 

    //buscar: double free


// se puede avanzar un byte del puntero haciendo literalmente puntero + 1 (cantidad de bytes)
// *(array+5) = 8;          estos son lo mismo; un array es un puntero al primer elemento
// array[5] = 8;        se puede usar sintaxis de array para otros punteros... 



}


// la segmentation fault es cuando le pedis a la ram bytes que tu compu no se guardó para tu programa, sino para otra cosa. 




void swap (int * a, int * b){
    int aux = *a;
    *a = *b;
    *b = aux;
}
// OJO: si *a es null te tira segmentation fault!!!

void swap_corrected (int * a, int * b){

    if(a && b){ // si es true, no es null √
    
        int aux = *a;
        *a = *b;
        *b = aux;
    
    }

}