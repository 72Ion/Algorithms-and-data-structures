// Cola con PRIORIDAD

#include <stdio.h>
#include <stdlib.h>

propiedades: (etiquetas que se pueden usar)                   //  x es "por":
                                                             //   x prioridad - x llegada    - Heap   // 
create(struct colaprio *c)                                           // O(1) - O(1)         - O(1)
destroy(struct colaprio *c)                                         // O(n) - vacia O(1)   - O(1)
encolar(struct colaprio *c, elem *c, int prioridad)                // O(1) - O(n)         - O(log n)
elemento * removeMax(struct colaprio *c)                          // O(n) - O(1)         - O(log n)
elemento * getMax(struct colaprio *c)                            // O(n) - O(1)         - O(1)
build(struct * colaprio, elem e[], int prio[], int cantidad)    // O(n) - O(n log n)   - O(n log n)
a build se lo llama Heapify

HEAP 

Definición de Heap: 


definiciones previas: 

    * árbol: es un grafo conexo acíclico. 
    * binario: tiene a lo sumo dos hijos.
    * hoja: hijo único. (sólo tiene conexión con el padre)
    * raíz: el nodo que no tiene padre. (es elejible, pero te das cuenta por el dibujo o por lógica)
    * (completo: todos los niveles están completos, excepto el último que puede no estarlo.) 

    struct Nodo {
        elem e;
        struct Nodo *izq;        // izq y der es el lado que tiene prioridad, esto le da calidad de "arbol completo -izquierda""
        struct Nodo *der;       // por ej en un heap maximo, el izq tiene que ser menor que el padre, y el der, mayor.
    };

    * heap: es un árbol binario completo, con la propiedad de que el valor de cada nodo es mayor o igual que el valor de sus hijos.

    * (mínimo de nodos: 3 (raíz, izq, der)
    * mínimo de nodos si no es completo: 2 (raíz, izq) --- 2^h , siendo (h = altura))
    * máximo de nodos: 2^(h+1) - 1 , siendo (h = altura)
    * completo izquierda: se completa de izquierda a derecha. 


                  0                   este es el nivel 0 
              /       \
             /         \
            /           \
           /             \ 
          0               0 
        /   \           /   \
       /     \         /     \ 
      0       0       0       0
     / \     / \     / \     / \
    0   0   0   0 ( 0   0   0   0 )   estos 4 podrían faltar en un heap completo izquierda. 
    
    - altura: 3 
    - nodos: 15 
    - nodos completos: 7 
    - nodos hoja: 8 
    - nodos no hoja/internos: 7


en programación se ve como una lista de 3 elementos: 
[ puntero_al_izq , variable_padre , puntero_al_der ]


ordenar                         O(n log n)
encolar n veces                 O(n log n)
n HeapDown desde la raíz        NO FUNCIONA
n HeapDown desde las hojas      O(n log n)      (va de atras para adelante)
n HeapUp desde la raíz          O(n log n)      
n HeapUp desde las hojas        O(n log n)      

HeapUp y HeapDown ordenan los datos dentro del árbol de mayor a menor. Lo que cambia en a quien muevo. 
es como la diferencia entre el bubbleSort normal y hacerlo desde el último al primero, y queda ordenado igual. 




