/*
VECTORES ESTÁTICOS (no cambian)
******************************* */

// con buffer de memoria, arreglo, array:

struct {
    int *p;
} vector;

vector*create (int largo) {p*(int*) malloc(sizeof(int)*largo),return p;} // malloc es O(n)
    destroy(vector *pV) {free(pV->p);}    // free es O(1)
    set_at (vector*pV, int pos, int valor) {pV -> p [pos] = valor;} // O(1)
    int get_at (vector *pV, int pos) {return pV -> p[pos];}  // O(1)

    //podría hacer muchas otras operaciones como promedio, etc


// con listas:
//ahora vamos a hacer vectores de tamaño estático usando listas:

    //enlazamos eslabones, o NODOS (lista enlazada) []->[]->[]...

    create(int n); //O()
    destroy(); //tenemos q usar una variable temporal // O(n)
    set_at (); //O(n) 
    get_at (); //O(n) tengo q iterar, no puedo indexar directo. si me piden el 80° itero 80 veces.


/*
VECTORES DE TAMAÑO DINÁMICO 
*************************** */

// con array

insert_at (int pos, int valor);  //O(n)    //quiero insertar un elemento en la "pos"ición tal. 
delete_at (int pos);            //O(n)    // quiero borrar el elemento de la posición tal
insert_last (int valor);        //O(n)
delete_last ();                 //O(n)  copia todo el array salvo el ult valor y libera el buffer. 
insert_first (int valor);       //O(n)
delete_first ();                //O(n)

// realloc hace algo parecido a esto y también tarda O(n)


// con listas

create(int n);             //O(n)
destroy();                 //O(n)
set_at ();                 //O(n)
get_at ();                 //O(n)
insert_at (int pos, int valor);  //O(n)
delete_at (int pos);             //O(n)
insert_last (int valor);         //O(n)  // O(1) si se usa un puntero al último pUltimo
delete_last ();                  //O(n)
insert_first (int valor);        //O(1) no tengo q recorrer nada, voy directo al valor
delete_first ();                 //O(1)

// las listas enlazadas se guardan en desorden en el SO. por ahi el 2do elemento lo agregaste al final de todo, entonces tu SO lo guardó con el # más alto. 
// >> por eso no se puede usar ___ sizeof ___ para hallar el último de la fila. no te va a dar bien nunca, además de que no hay un sizeof para la lista, sino para cada uno de los elementos, no me sirve para vacer un len(), solo sirve para saber cuanto pesa en bytes el elemento tal. 

//DUDA:  porqué insert_first y delete_first no son O(1) en arrays pero sí en listas?? 


struct 
{
    int valor;
    nodo * sig;
    nodo;
}

struct VecDim
{
    nodo *p;
    nodo *pUlt;
}


// _________________________________ posibles mejoras

// vector dinámico con array
struct {
    int *p;

    // podría agregar:

    int tamaño; // listo, este es el len xq me lo digo el programador
    int reservado; 
    // una posible implementación sería duplicar el tamaño del array cada vez que me quedo sin espacio. si tengo un array de 2 y me piden uno más le devuelvo 4 lugares, me piden 9 y le devuelvo 16...etc PORQUÉ?????????? porque harias eso??
    // el usuario piensa que tiene un array de tantos lugarcitos, pero en realidad yo sé que tengo muchos más, tengo de sobra casi siempre. 
    // log2(n) veces re- aloqué el buffer, es decir cambié el len de mi array. (ES VERDAD?)

} vector;







/////////////////////////////////////////////



// lista simplemente enlazada 



// un for que no tiene incremento funciona como un while:

for ( , primero != null, ){
    
}







///////////////////////////////


//listas
/*
                    con puntero al ultimo       sin puntero al ult

insertar_primero            O(1)                        O(1)
insertar_ultimo             O(1)                        O(n)
borrar_primero              O(1)                        O(1)
borrar_ultimo               O(n)                        O(n)

*/


Pila (stack)        // LIFO

//interfaz:                             con listas          con vectores de tam dinamico

void  crearPila(struct pila *p);                          O(1)                    O(1)
void  destruirPila(struct pila *p);                       O(n)                    O(1)
void  apilar(struct pila *p, int v);          O(1)                    O(1)
int   desapilar_o_pop(struct pila *p);        O(1)                    O(1)
//el int es xq tiene un return de un int: retorna el coso que desapilaste . 
// en general usamos listas de ints para no hacer mucho lio. por eso devolvemos ints 

/// usos: Hanoii, algs de búsqueda, 


//implementación: se pueden usar para BFS y DFS stack/queue (lo necesitan)


Fila (Queue)        // FIFO , cola          
// queue & dequeue                          con listas      vec de tam dinamico

void crearCola(struct cola *c);                 O(1)            O(1)
void destruirCola(struct cola *c);              O(n)            O(1)
void encolar(struct cola *c ,int v);            O(1)            O(1)    O(n)
// v es el nuevo valos a encolar
int desencolar_o_pop(struct cola *c);           O(1)            O(n)    O(1)
//                                                      agrego final   saco final
//                                                         saco ppio   agrego ppio


int fibo_recursivo ( int i ) {
    if ( i <= 2 ) return 1;
    return fibo_recursivo( i - 2 ) + fibo_recursivo( i - 1 );
}

// ejs: 1) cómo implementar una cola con dos pilas
// ejs: 2) cómo implementar una pila con dos colas
// ejs: 3) problema del carnaval: los carros vienen de a 1 en desorden, tengo que ordenarlos, hay un corte de calle. 







listas enlazadas ordenadas:

las listas doble/triple/n-mente enlazadas sirven para hacer búsquedas mucho más rápidas.
pero es un lio cuando quiero insertar un elemento por la complejidad de la estructura. al momento de insertar el nodo tiene que decidir aleatoriamente que nivel tiene (si es una lista doble, decide entre nivel uno o dos.)

el peor caso es cuando se te borran todos los nodos de niveles más altos, o te quedan todos los nodos del mismo nivel. de esta forma queda una lista enlazada simple (o se comporta como tal).
vale destacar que estos casos son escandalosamente improbables. 

mejor caso:   par de operaciones
caso normal:  O(log n)
peor caso:    O(n)